package khangman;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class ImpiccatoGrafica extends JFrame {       //dichiaro i componenti dell'interfaccia grafica
    
    private JLabel etichettaParola, etichettaTentativi, etichettaInserimento;

    private JTextField campoInserimento;

    private JButton bottoneInvia;

    
    //dichiaro le variabili che verranno usate durante il gioco

    private String parola;

    private List<Character> lettereIndovinate;

    private int tentativiRimasti;

    
    public ImpiccatoGrafica() {  //costruttore della classe che inizializza l'interfaccia grafica e avvia il gioco

        setTitle("Impiccato");  //imposto il titolo della finestra

        setVisible(true);       //visibilità a true per rendere la finestra visibile

        setSize(500, 400);      //imposto le dimensioni della finestra

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        //inizializzo i componenti dell'interfaccia grafica

        etichettaParola = new JLabel("Parola: ");

        etichettaTentativi = new JLabel("Tentativi rimanenti: ");

        etichettaInserimento = new JLabel("Inserisci una lettera: ");

        campoInserimento = new JTextField();

        bottoneInvia = new JButton("Invia");


        //creo il pannello superiore contenente etichette e campo di input

        JPanel pannelloSuperiore = new JPanel();

        pannelloSuperiore.setLayout(new GridLayout(3, 2));

        pannelloSuperiore.add(etichettaParola);

        pannelloSuperiore.add(etichettaTentativi);
        
        pannelloSuperiore.add(new JLabel(""));
        
        pannelloSuperiore.add(etichettaInserimento);

        pannelloSuperiore.add(campoInserimento);

        setLayout(new GridLayout(4, 1));        //impostazione del layout della finestra

        add(etichettaParola);           //aggiungo i componenti alla finestra

        add(etichettaTentativi);

        add(pannelloSuperiore);
        
        add(bottoneInvia);

        add(bottoneInvia, BorderLayout.SOUTH);


        bottoneInvia.addActionListener(new ActionListener() {       //aggiungo l'actionlistener per il pulsante invia

            public void actionPerformed(ActionEvent e) {

                invio();    //richiama il metodo invio quando premuto

            }
        });

        parola = scegliParolaDaFile("parole.csv");      //scelgo la parola randomicamente dal file csv e inizializzo le variabili che utilizzerò nel gioco

        tentativiRimasti = 9;

        lettereIndovinate = new ArrayList<>();

        inizializzaInterfaccia();       //inizializzo l'interfaccia grafica del gioco

        aggiornaInterfaccia();      //aggiorno l'interfaccia grafica per visualizzare la parola censurata e i tentativi rimasti (lo stato del gioco in generale)

    }


    private String scegliParolaDaFile(String nomeFile) {     //metodo per scegliere casualmente una parola da un file di testo

        List<String> parole = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(nomeFile))) {

            String riga;

            while ((riga = br.readLine()) != null) {
                
                parole.add(riga);

            }

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this, "Errore durante la lettura del file.");
            
        }

        Random rand = new Random();

        return parole.get(rand.nextInt(parole.size()));     //ritorna una parola casuale dalla lista parole

    }


    private void inizializzaInterfaccia() {     //metodo per inizializzare l'interfaccia grafica con la parola segreta censurata

        String trattini = "";

        for (int i = 0; i < parola.length(); i++) {

            trattini += " _";       //stampo a video la lunghezza della parola in trattini
        }

        etichettaParola.setText("Parola: " + trattini);

        etichettaTentativi.setText("Tentativi rimanenti: " + tentativiRimasti);

    }


    private void invio() {      //metodo per gestire l'invio di una mossa da parte dell'utente

        String input = campoInserimento.getText();          //prende l'input inserito dall'utente
        
        if (input.length() != 1 || !Character.isLetter(input.charAt(0))) {      //controlla se l'input dato è una sola lettera o no

            JOptionPane.showMessageDialog(this, "Inserisci una singola lettera valida.");

            return;     //esce dal programma se l'input non è valido
        }

        char lettera = input.charAt(0);

        if (lettereIndovinate.contains(lettera)) {      //controlla se la lettera data in input era già stata inserita in precedenza,
                                                        //se sì bisogna reinserirla e i tentativi non vengono scalati

            JOptionPane.showMessageDialog(this, "Hai già inserito questa lettera.");

            return;
        }

        if (parola.contains(input + "")) {      //all'argomento ho aggiunto anche + "" perchè, siccome voglio avere la parola leggermente spaziata, se avessi dato una lettera
                                                // già inserita in precedenza non l'avrebbe rilevata

            lettereIndovinate.add(lettera);     //aggiunge la lettera alle lettere indovinate se è presente nella parola

        } 
        
        else {

            tentativiRimasti--;     //decrementa il numero di tentativi rimasti se la lettera non è presente nella parola

        }

        aggiornaInterfaccia();  //aggiorno l'interfaccia grafica del gioco

        campoInserimento.setText("");       //resetto il campo di inserimento per quando inserirò la prossima lettera

    }


    private void aggiornaInterfaccia() {        //metodo per aggiornare l'interfaccia grafica del gioco

        String parolaVisualizzata = "";

        for (int i = 0; i < parola.length(); i++) {

            char lettera = parola.charAt(i);

            if (lettereIndovinate.contains(lettera)) {

                parolaVisualizzata += lettera;      //stampa a video la lettera se è stata indovinata

            } 
            
            else {

                parolaVisualizzata += " _";     //se non è stata ancora indovinata vengono stampati a video dei trattini bassi

            }
        }

        etichettaParola.setText("Parola: " + parolaVisualizzata);       //aggiorno la label della parola

        etichettaTentativi.setText("Tentativi rimasti: " + tentativiRimasti);     //aggiorno la label dei tentativi rimasti


        if (tentativiRimasti == 0) {        //in caso di sconfitta, ovvero se si hanno esaurito i
						tentativi

            JOptionPane.showMessageDialog(this, "Hai perso! La parola era: " + parola);

            bottoneInvia.setEnabled(false);     //disabilito il pulsante invia sennò posso ancora decrementare i tentativi e (possibilmente) andare in negativo

        } 
        
        else if (!parolaVisualizzata.contains(" _")) {        //in caso di vittoria, ovvero se la									parola non contiene più trattini

            JOptionPane.showMessageDialog(this, "Hai vinto!");

            bottoneInvia.setEnabled(false);     //disabilito il pulsante invia sennò posso ancora decrementare i tentativi e (possibilmente) andare in negativo

        }
    }


    public static void main(String[] args) {

        ImpiccatoGrafica gioco = new ImpiccatoGrafica();
    }
}