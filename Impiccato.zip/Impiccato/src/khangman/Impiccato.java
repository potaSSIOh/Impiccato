package khangman;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Impiccato {


    private static String scegliParola(String nomeFile) {      //metodo per leggere una parola randomica da un file di testo

        List<String> parole = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(nomeFile))) {
            String riga;
            
            while ((riga = br.readLine()) != null) {        //ogni riga del file viene letta e aggiunge ogni parola alla lista

                parole.add(riga);
            }

        } catch (IOException e) {           //catturo l'eccezione se il file non esiste

            System.out.println("File inesistente.");
        }

        Random rand = new Random();

        return parole.get(rand.nextInt(parole.size()));             //viene restituita in modo randomico la parola scelta per il gioco

    }


    //metodo che stampa un trattino per ogni carattere della parola (in modo da avere la parola censurata all'inizio)

    private static void getParolaCensurata(String parola) {

        for (int i = 0; i < parola.length(); i++) {

            System.out.print("_");              //ho messo il trattino per comodità
        }
        
        System.out.println();
    }

    
    //metodo che verifica se la lettera inserita dall'utente è presente nella parola che è stata estratta

    private static boolean letteraPresente(Scanner s, String parola, List<Character> lettereIndovinate) {

        System.out.println("Inserisci una lettera:");

        String letteraEffettiva = s.nextLine();

        char letteraIndovinata = letteraEffettiva.charAt(0);

        if (parola.contains(letteraEffettiva)) {

            lettereIndovinate.add(letteraIndovinata);       //se la lettera effettiva è presente nella parola, aggiunge la lettera alla lista delle lettere indovinate

            return true;        //ritorna true se la lettera è presente nella parola

        } else {
            
            return false;       //ritorna false se la lettera non è presente nella parola

        }
    }


    //metodo che stampa la parola con le lettere indovinate e gli underscore per quelle non indovinate

    private static boolean stampaParola(String parola, List<Character> lettereIndovinate) {

        int corrette = 0;

        for (int i = 0; i < parola.length(); i++) {

            if (lettereIndovinate.contains(parola.charAt(i))) {

                System.out.print(parola.charAt(i));         //stampa la lettera se è stata indovinata

                corrette++;

            } else {

                System.out.print("_");          // Stampa un trattino se la lettera non è stata indovinata

            }
        }

        System.out.println();

        return (parola.length() == corrette);           // Restituisce true se tutte le lettere della parola sono state indovinate

    }
    

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
    
        String parola = scegliParola("parole.csv");
    
        List<Character> lettereIndovinate = new ArrayList<>(); 
    
        int tentativiMassimi;

        System.out.println("Inserisci un numero massimo di tentativi:");

        try {           //controllo che venga inserito un int e non un float, char, String...

            tentativiMassimi = s.nextInt();

            s.nextLine();       //se lo tolgo mi restituisce index out of bounds, ho cercato ed è un problema di input legato al buffer e quindi l'ho tenuto per evitare problemi

        } catch (InputMismatchException e) {

            System.out.println("Numero massimo di tentativi non valido.");
            
            return;             //esce dal programma se l'input non è valido
        }
    
        int tentativiSbagliati = 0;

        getParolaCensurata(parola);
        
        while (true) {          //fa iniziare il gioco

            if (tentativiSbagliati >= tentativiMassimi) {           //se il numero di tentativi sbagliati raggiunge i tentativi massimi, l'utente ha perso

                System.out.println("Hai perso!");

                System.out.println("La parola e': " + parola);

                break;      //inserito per uscire dal ciclo

            }

            if (!letteraPresente(s, parola, lettereIndovinate)) {       //se l'utente non ha indovinato la lettera, vengono aumentati i tentativi sbagliati

                tentativiSbagliati++;

                System.out.println("La lettera inserita non e' presente nella parola! Tentativi rimanenti: " + (tentativiMassimi - tentativiSbagliati));

            }

            if (stampaParola(parola, lettereIndovinate)) {          //se l'utente indovina tutte le lettere della parola ha vinto

                System.out.println("Hai vinto!");

                break;      //inserito per uscire dal ciclo
            }
        }
    }
}